import pygame, os, sys, random

os.environ['SDL_VIDEO_CENTERED'] = '1'

# Variables
WHITE = (255, 255, 255)
GREY = (80, 80, 80)
GREEN = (75, 150, 75)
RED = (255, 0, 0)
BLACK = (0, 0, 0)

SHIP_HEIGHT = 50
SHIP_WIDTH = 30

WIN_W = 16*32
WIN_H = 700

TIMER = 0


class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((32, 32))
        self.image.convert()
        self.image.fill(GREY)
        self.rect = pygame.Rect(x, y, 32, 32)


class Ship(pygame.sprite.Sprite):
    def __init__(self, container):
        pygame.sprite.Sprite.__init__(self)
        self.side_speed = 5
        self.top_speed = 4
        self.image = pygame.Surface((SHIP_WIDTH, SHIP_HEIGHT)).convert()
        self.image.fill(GREEN)
        self.rect = self.image.get_rect()
        self.rect.centerx = container.centerx
        self.rect.y = container.bottom - self.rect.height * 3
        self.container = container
        self.damage = 3

    def update(self, camera_entity, bullet_group, huey_bullet_group):
        global TIMER
        if camera_entity.is_moving:
            self.rect.y -= 1

        if self.rect.y >= camera_entity.rect.y + WIN_H/2 - self.rect.height:
            self.rect.y = camera_entity.rect.y + WIN_H/2 - self.rect.height
        if self.rect.y <= camera_entity.rect.y - WIN_H/2:
            self.rect.y = camera_entity.rect.y - WIN_H/2

        # Movement
        if camera_entity.rect.y < self.container.bottom - WIN_H/2:
            key = pygame.key.get_pressed()
            if key[pygame.K_w]:
                self.rect.y -= self.top_speed
            if key[pygame.K_s]:
                self.rect.y += self.top_speed
            if key[pygame.K_a]:
                self.rect.x -= self.side_speed
            if key[pygame.K_d]:
                self.rect.x += self.side_speed
            self.rect.clamp_ip(self.container)

            if TIMER % 20 == 0:
                key = pygame.key.get_pressed()
                if key[pygame.K_SPACE]:
                    B = Bullet(self.container,  self.rect.centerx + 5, self.rect.y + 10, "ship", 180)
                    B1 = Bullet(self.container, self.rect.centerx - 5, self.rect.y + 10, "ship", 180)
                    bullet_group.add(B, B1)

        collisions = pygame.sprite.spritecollide(self, huey_bullet_group, True)
        for p in collisions:
            self.damage -= 1

        if self.damage <= 0:
            self.kill()


class Camera(object):
    def __init__(self, t_width, t_height):
        self.state = pygame.Rect(0, 0, t_width, t_height)

    def apply(self, target):
        return target.rect.move(self.state.topleft)

    def update(self, target_rect, came):
        x = -target_rect.x + WIN_W / 2
        y = -came.rect.y + WIN_H / 2

        if x > 0:
            x = 0
        elif x < -(self.state.width - WIN_W):
            x = -(self.state.width - WIN_W)

        if y > 0:
            y = 0
        elif y < -(self.state.height - WIN_H):
            y = -(self.state.height - WIN_H)

        self.state = pygame.Rect(x, y, self.state.width, self.state.height)


class Camera_Entity(pygame.sprite.Sprite):
    def __init__(self, container):
        self.container = container
        self.image = pygame.Surface((10, 10)).convert()
        self.image.fill(GREEN)
        self.rect = self.image.get_rect()
        self.rect.centerx = container.width/2
        self.rect.centery = container.height
        self.is_moving = False

    def update(self):
        if self.rect.y < WIN_H/2:
            self.rect.y += 1
        self.rect.y -= 1

        if self.rect.y < self.container.bottom - WIN_H/2:
            self.is_moving = True
        if self.rect.y < WIN_H/2:
            self.is_moving = False
        if self.rect.y < 0:

            self.rect.y = 0


class Bullet(pygame.sprite.Sprite):
    def __init__(self, container, x, y, type_bullet, angle):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((5, 5)).convert()
        self.image.fill(BLACK)
        self.rect = self.image.get_rect()
        self.speed = 6
        self.rect.centerx = x
        self.rect.y = y
        self.container = container
        self.type = type_bullet
        self.angle = angle

    def update(self):
        if self.type == "ship":
            self.rect.y -= self.speed

        elif self.type == "huey":
            self.rect.y += self.speed
            self.rect.x += self.angle

        if self.rect.y < 0 or self.rect.y > self.container.height or self.rect.x < 0 or self.rect.x > self.container.width:
            self.kill()


class Huey(pygame.sprite.Sprite):
    def __init__(self, container):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((80, 50)).convert()
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.container = container
        self.rect.centerx = random.randrange(int(self.rect.width/2), int(self.container.width) - int(self.rect.width/2))
        self.rect.centery = -self.rect.height
        self.damage = 10
        self.e = int(random.choice("12"))

    def update(self, huey_bullet_group, sbullet_group, camera_entity):
        global TIMER

        if TIMER < 12 * 60:
            self.rect.y += 1
        if TIMER > 14 * 60:
            if self.e == 1:
                self.rect.x -= 1
            if self.e == 2:
                self.rect.x += 1
        if camera_entity.rect.y < self.container.bottom - WIN_H/2:
            if TIMER % 120 == 0 and TIMER > 10 * 60:
                B = Bullet(self.container, self.rect.centerx, self.rect.y + 10, "huey", -5)
                B1 = Bullet(self.container, self.rect.centerx, self.rect.y + 10, "huey", 0)
                B2 = Bullet(self.container, self.rect.centerx, self.rect.y + 10, "huey", 5)
                huey_bullet_group.add(B, B1, B2)

        collisions = pygame.sprite.spritecollide(self, sbullet_group, True)
        for p in collisions:
            self.damage -= 1

        if self.damage <= 0:
            self.kill()

        if self.rect.x < -self.rect.width or self.rect.x > self.container.width:
            self.kill()


def main():
    global TIMER

    pygame.init()

    # Create Game Variables
    FPS = 60
    clock = pygame.time.Clock()
    play = True
    pygame.display.set_caption("Raiden 2")
    screen = pygame.display.set_mode((WIN_W, WIN_H), pygame.SRCALPHA)

    # Create Game Objects
    platform_group = pygame.sprite.Group()

    # Load Level
    level = [
        "PPPPPPPPPPPPPPPPPPPPPP",
        "P                    P",
        "P                    P",
        "P             PPPPPPPP",
        "P                    P",
        "PPPPPPPP             P",
        "P                    P",
        "P                    P",
        "P                    P",
        "P              PPPPPPP",
        "P                    P",
        "P                    P",
        "PPPPPP               P",
        "P                    P",
        "P               PPPPPP",
        "PPPPP                P",
        "P                    P",
        "P                    P",
        "P              PPPPPPP",
        "P                    P",
        "PPPPPP               P",
        "P                    P",
        "P                    P",
        "P                    P",
        "P             PPPPPPPP",
        "P                    P",
        "PPPPPPPP             P",
        "P                    P",
        "P                    P",
        "P                    P",
        "P              PPPPPPP",
        "P                    P",
        "P                    P",
        "PPPPP                P",
        "P                    P",
        "P                    P",
        "P              PPPPPPP",
        "P                    P",
        "PPPPPP               P",
        "P                    P",
        "P                    P",
        "P                    P",
        "P             PPPPPPPP",
        "P                    P",
        "PPPPPPPP             P",
        "P                    P",
        "P                    P",
        "P                    P",
        "P              PPPPPPP",
        "P                    P",
        "P                    P",
        "PPPPPPPPPPPPPPPPPPPPPP", ]

    # Build Level
    x = y = 0
    for row in level:
        for col in row:
            if col == "P":
                p = Platform(x, y)
                platform_group.add(p)
            x += 32
        y += 32
        x = 0

    # Set Up Camera
    t_width = len(level[0]) * 32
    t_height = len(level) * 32
    camera = Camera(t_width, t_height)

    container = pygame.Rect(0, 0, len(level[0]) * 32, len(level) * 32)
    ship = Ship(container)
    ship_group = pygame.sprite.Group()
    ship_group.add(ship)

    huey_group = pygame.sprite.Group()
    h = Huey(container)
    huey_group.add(h)

    ship_bullet_group = pygame.sprite.Group()
    huey_bullet_group = pygame.sprite.Group()

    camera_entity = Camera_Entity(container)
    # Gameplay
    while play:
        TIMER += 1

        if TIMER % (20 * 60) == 0:
            h = Huey(container)
            huey_group.add(h)
        # Checks if window exit button pressed
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()

        # Update
        ship_group.update(camera_entity, ship_bullet_group, huey_bullet_group)
        huey_group.update(huey_bullet_group, ship_bullet_group, camera_entity)
        camera.update(ship.rect, camera_entity)
        camera_entity.update()

        # Draw Everything
        screen.fill(WHITE)
        for p in platform_group:
            screen.blit(p.image, camera.apply(p))
        for s in ship_group:
            screen.blit(s.image, camera.apply(s))
        for b in ship_bullet_group:
            b.update()
            screen.blit(b.image, camera.apply(b))
        for b in huey_bullet_group:
            b.update()
            screen.blit(b.image, camera.apply(b))
        for h in huey_group:
            screen.blit(h.image, camera.apply(h))

        screen.blit(camera_entity.image, camera.apply(camera_entity))

        # Limits frames per iteration of while loop
        clock.tick(FPS)
        # Writes to main surface
        pygame.display.flip()


if __name__ == "__main__":
 main()